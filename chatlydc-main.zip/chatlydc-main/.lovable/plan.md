# Chatly — Final Sürüm Planı

Bu plan büyük bir yeniden yapılandırma. Onaylamadan önce birkaç netleştirme sorusu da var, en altta.

## 1. Veritabanı değişiklikleri (tek migration)

### Yeni / değişen tablolar
- **profiles**
  - `tag`: 4 hane → **6 hane** (10K → 1M kombinasyon). Daha da güvenli olması için tag formatı `0001-999999` arası, asla yeniden kullanılmaz.
  - `avatar_url` zaten var; Storage'a bağlanacak.
  - Yeni: `deleted_at` (soft delete) — hesap silindiğinde `username`'i `[silinmiş kullanıcı]`, `tag`'i serbest bırakmadan tutarız (kesişme olmaması için).
  - Yeni tablo `reserved_tags(username, tag)` — silinen hesapların tag'leri buraya geçer, asla tekrar verilmez.

- **channels** (genişletildi)
  - `owner_id` (uuid) — kanal sahibi
  - `visibility`: enum `('public','invite','private')` — açık / sadece davet / kapalı
  - `is_official` (bool) — sadece sistem ana kanalları (#genel, #oyun, #müzik). Yeni kullanıcılar bunları ana yapamaz.
  - `slug` (unique), `icon_url`, `description`, `created_at`

- **channel_members** (yeni)
  - `channel_id, user_id, role enum('owner','mod','member','banned'), joined_at`
  - Üyelik + rol + ban tek tabloda.

- **channel_invites** (yeni)
  - `code (unique), channel_id, created_by, expires_at, max_uses, uses`

- **channel_tags** (yeni) — kanala özel etiketler (rol/rozet gibi)
  - `id, channel_id, name, color`
  - **member_tags**: `channel_id, user_id, tag_id`

- **messages** — değişiklik yok (zaten var, edit/delete çalışıyor).

### Storage
- `avatars` bucket (public read, kullanıcı kendi klasörüne yazar)
- `channel-icons` bucket (public read, sadece owner yazar)

### Güvenlik (RLS) — özet
- Profilleri herkes (auth) görebilir ama sadece sahibi günceller.
- Kanal görünürlüğü: `public` → herkes okur; `invite`/`private` → sadece `channel_members`.
- Mesajlar: sadece kanal üyesi okur/yazar; ban'lı yazamaz.
- Mod/owner kontrolü için `has_channel_role(user, channel, role)` SECURITY DEFINER fonksiyonu (recursion önlemek için).
- Kanal silme: yalnız `owner` ve `is_official=false`.
- Kanal yasaklama (ban): owner + mod yapabilir; owner'ı kimse atamaz.

## 2. Hesap yönetimi
- Kayıt: e-posta+şifre + Google. Şifre HIBP kontrolü açık.
- **Hesap silme**: `delete-account` server function → tag'i `reserved_tags`'e taşı, profili soft-delete, `auth.admin.deleteUser` ile auth'tan kaldır. Kullanıcıdan şifre doğrulaması ister.
- Profil fotoğrafı: Storage'a yükle, `profiles.avatar_url` güncelle.

## 3. Kullanıcı arayüzü

### Sol rail (sunucu çubuğu)
- Ana sayfa (DM/feed yerine ana kanallar listesi)
- Kullanıcının üye olduğu kanallar (ikonlar)
- **+ Kanal oluştur** (modal: ad, açıklama, görünürlük, ikon)
- **🧭 Keşfet** butonu

### Keşfet sayfası (`/discover`)
- Arama kutusu (en üstte ana resmi kanallar — `is_official` önce)
- Public kanallar listesi (üye sayısı, açıklama, "Katıl" butonu)
- Davet kodu ile katılma input'u

### Kanal görünümü
- Kanal başlığı + sahibi ⚙️ ayarları görür (ad, ikon, görünürlük, davet linkleri, etiketler, mod listesi, ban listesi, sil)
- Üye listesi: rol rozetleri (owner/mod) + kanal etiketleri (renkli)
- Üye sağ tık menüsü (owner/mod): "Mod yap / Mod'u al / Etiket ver / Yasakla / Kanaldan at"
- "Kanaldan ayrıl" butonu

### Üst bar
- Dil seçici (TR/EN — i18n basit dict)
- Ayarlar: profil, avatar yükle, kullanıcı adı/tag, **Hesabı sil**

### Politika & uyarılar
- İlk girişte modal: "Bu deneysel bir platformdur. İçerikten kullanıcılar sorumludur, anarşik ortam oluşabilir, hiçbir sorumluluk kabul edilmez." → kabul edilmeden devam yok. `profiles.policy_accepted_at` saklanır.
- `/terms` ve `/privacy` route'ları.

## 4. Sesli/görüntülü sohbet
**Karar gerekli (aşağıda soru var).** Discord seviyesi gerçek bir SFU (ör. LiveKit) ücretli altyapı ister. Minimum uygulanabilir versiyon: kanal başına **WebRTC mesh (≤4 kişi)**, Supabase Realtime'ı sinyalleşme için kullanırız. Mikrofon/kamera izinleri tarayıcı tarafından istenir; reddedilirse sonradan "İzinleri Yenile" butonu prompt'u tekrar tetikler (`navigator.permissions.query` + getUserMedia tekrar dene). Geniş ölçek (8+ kişi) için sonra LiveKit entegre edilir.

## 5. i18n
- `src/i18n/{tr,en}.ts` basit anahtar sözlüğü + `useT()` hook
- Tüm metinler `t('chat.send')` gibi anahtarlardan gelir
- Başlangıçta TR + EN; daha sonra dil eklemek kolay

## 6. Güvenlik kontrol listesi
- Tüm tablolarda RLS açık + scope'lu policy'ler
- `has_channel_role` SECURITY DEFINER (RLS recursion yok)
- `tag` sunucu tarafında üretilir (client asla kendi tag'ini seçemez → taklit önlenir)
- Username değişikliğinde `(username, tag)` unique → çakışma engellenir
- Hesap silme şifre doğrulaması ister
- Server function'larda Zod input doğrulaması
- Storage policy'leri: kullanıcı sadece kendi `avatars/{uid}/...` klasörüne yazar
- HIBP password check açık

## Yapı (teknik özet)
- Migration: 1 dosya (tüm tablolar + policy'ler + storage bucket'ları + has_channel_role + reserved_tags akışı)
- Server functions: `delete-account.functions.ts`, `join-channel.functions.ts`, `create-invite.functions.ts`, `set-member-role.functions.ts`, `ban-member.functions.ts`, `upload-avatar` (client → storage doğrudan), `create-channel.functions.ts`, `delete-channel.functions.ts`
- Routes: `/auth`, `/chat` (yeniden yazılacak), `/discover`, `/channel/$id/settings`, `/settings`, `/terms`, `/privacy`, `/invite/$code`
- Components: `ChannelSettingsDialog`, `MemberContextMenu`, `CreateChannelDialog`, `DiscoverList`, `VoiceRoom`, `PolicyGate`, `LanguageSwitcher`, `AvatarUploader`
- i18n: `src/i18n/` + `LanguageProvider`

---

## Onaylamadan önce 3 soru

1. **Sesli/görüntülü sohbet kapsamı**: Şimdilik basit WebRTC mesh (≤4 kişi, ek ücret yok) yeterli mi, yoksa daha büyük odalar için LiveKit gibi ek bir servisi sonra mı entegre edelim? *Önerilen: önce mesh ile başla.*
2. **Tag uzunluğu**: 6 hane (1M kombinasyon, ABCD#000001) mı, yoksa 4 harf+4 rakam mı (60M+ kombinasyon, Ada#A1B2) tercih edersin? *Önerilen: 6 hane sayısal, Discord stiline yakın.*
3. **Resmi kanallar**: Mevcut #genel, #oyun, #müzik kanalları "official" olarak işaretlenip silinemez/değiştirilemez kalsın mı (tüm yeni üyeler otomatik katılır)? *Önerilen: evet.*

Onay verirsen migration'la başlayıp tüm akışı kuruyorum.